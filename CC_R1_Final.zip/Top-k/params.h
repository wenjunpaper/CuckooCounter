#ifndef _PARAMS_H
#define _PARAMS_H

#define MAX_INSERT 1000000
#define N MAX_INSERT  // maximum flow
#define M MAX_INSERT  // maximum size of stream-summary
#define MAX_MEM MAX_INSERT // maximum memory size
#define HK_d 2 // maximum memory size

#define KEY_LEN 13

#endif //_PARAMS_H
